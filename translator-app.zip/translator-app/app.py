"""
Translator App usando Qwen2-0.5B via Hugging Face transformers
No requiere API keys externas - corre localmente
"""

from flask import Flask, request, jsonify, send_from_directory
import os
import sys

app = Flask(__name__, static_folder="static")

# ── Carga del modelo ────────────────────────────────────────────────────────
print("⏳ Cargando modelo Qwen2-0.5B-Instruct...")

try:
    from transformers import AutoModelForCausalLM, AutoTokenizer
    import torch

    MODEL_NAME = "Qwen/Qwen2-0.5B-Instruct"
    tokenizer = AutoTokenizer.from_pretrained(MODEL_NAME)
    model = AutoModelForCausalLM.from_pretrained(
        MODEL_NAME,
        torch_dtype=torch.float32,   # CPU friendly
        device_map="auto",
    )
    model.eval()
    MODEL_LOADED = True
    print("✅ Modelo listo.")
except Exception as e:
    MODEL_LOADED = False
    LOAD_ERROR = str(e)
    print(f"❌ Error cargando modelo: {e}", file=sys.stderr)


LANGUAGES = {
    "en": "English",
    "es": "Spanish",
    "fr": "French",
    "de": "German",
    "it": "Italian",
    "pt": "Portuguese",
    "zh": "Chinese",
    "ja": "Japanese",
    "ko": "Korean",
    "ar": "Arabic",
    "ru": "Russian",
}


def translate(text: str, source_lang: str, target_lang: str) -> str:
    if not MODEL_LOADED:
        raise RuntimeError(f"Modelo no disponible: {LOAD_ERROR}")

    src_name = LANGUAGES.get(source_lang, source_lang)
    tgt_name = LANGUAGES.get(target_lang, target_lang)

    system_prompt = (
        "You are a professional translator. "
        "Translate the given text accurately. "
        "Return ONLY the translated text, nothing else."
    )
    user_prompt = f"Translate from {src_name} to {tgt_name}:\n{text}"

    messages = [
        {"role": "system", "content": system_prompt},
        {"role": "user",   "content": user_prompt},
    ]

    text_input = tokenizer.apply_chat_template(
        messages, tokenize=False, add_generation_prompt=True
    )
    inputs = tokenizer([text_input], return_tensors="pt").to(model.device)

    with __import__("torch").no_grad():
        output_ids = model.generate(
            **inputs,
            max_new_tokens=256,
            temperature=0.1,
            do_sample=False,
            pad_token_id=tokenizer.eos_token_id,
        )

    generated = output_ids[0][inputs.input_ids.shape[1]:]
    result = tokenizer.decode(generated, skip_special_tokens=True).strip()
    return result


# ── Rutas ───────────────────────────────────────────────────────────────────
@app.route("/")
def index():
    return send_from_directory("static", "index.html")


@app.route("/api/translate", methods=["POST"])
def api_translate():
    data = request.get_json(force=True)
    text        = (data.get("text") or "").strip()
    source_lang = data.get("source_lang", "en")
    target_lang = data.get("target_lang", "es")

    if not text:
        return jsonify({"error": "El campo 'text' es requerido."}), 400
    if source_lang == target_lang:
        return jsonify({"translation": text})

    try:
        translation = translate(text, source_lang, target_lang)
        return jsonify({"translation": translation})
    except Exception as e:
        return jsonify({"error": str(e)}), 500


@app.route("/api/languages")
def api_languages():
    return jsonify(LANGUAGES)


@app.route("/api/status")
def api_status():
    return jsonify({"model_loaded": MODEL_LOADED})


if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000, debug=False)
