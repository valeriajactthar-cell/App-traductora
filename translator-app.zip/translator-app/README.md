# 🌐 Qwen Translator — Traductor con IA Local

Aplicación de traducción de idiomas usando **Qwen2-0.5B-Instruct** corriendo localmente.  
**No requiere API keys externas.**

---

## ✅ Ejemplos de prueba incluidos

| Texto original (EN) | Traducción esperada (ES)         |
|---------------------|----------------------------------|
| I like soccer       | Me gusta el fútbol               |
| How are you?        | ¿Cómo estás?                     |
| What time is it?    | ¿Qué hora es?                    |

---

## 🚀 Instalación y uso

### Requisitos
- Python 3.9 o superior
- ~2 GB de espacio en disco (para el modelo)
- Conexión a internet la primera vez (descarga el modelo desde Hugging Face)

### Pasos

```bash
# 1. Clonar / descomprimir el proyecto
cd translator-app

# 2. Crear entorno virtual (recomendado)
python -m venv .venv
source .venv/bin/activate        # Linux / macOS
# .venv\Scripts\activate         # Windows

# 3. Instalar dependencias
pip install -r requirements.txt

# 4. Ejecutar la app
python app.py
```

### Acceso

Abre tu navegador en: **http://localhost:5000**

---

## 🗂 Estructura del proyecto

```
translator-app/
├── app.py              # Backend Flask + carga de Qwen2-0.5B
├── requirements.txt    # Dependencias Python
├── README.md           # Este archivo
└── static/
    └── index.html      # Frontend (HTML + CSS + JS)
```

---

## 🌍 Idiomas soportados

Inglés, Español, Francés, Alemán, Italiano, Portugués,  
Chino, Japonés, Coreano, Árabe, Ruso.

---

## ⚙️ Detalles técnicos

| Componente  | Detalle                                |
|-------------|----------------------------------------|
| Modelo      | `Qwen/Qwen2-0.5B-Instruct`             |
| Backend     | Flask (Python)                         |
| Frontend    | HTML + CSS + JS vanilla                |
| Librería ML | Hugging Face `transformers`            |
| Hardware    | CPU (funciona sin GPU)                 |
| API keys    | ❌ No requeridas                        |

> **Nota:** La primera ejecución descargará el modelo (~1 GB). Las siguientes serán más rápidas gracias al caché de Hugging Face.

---

## 🎨 Funcionalidades

- ✅ Traduce entre 11 idiomas
- ✅ Intercambio de idiomas con un clic
- ✅ Indicador de estado del modelo
- ✅ Ejemplos de prueba preconfigurados
- ✅ Atajo de teclado `Ctrl+Enter` para traducir
- ✅ Botón de copiar traducción
- ✅ Contador de caracteres (máx. 2000)
